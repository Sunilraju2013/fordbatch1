package com.ford.inventory;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.IOException;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.ford.inventory.repository.UserRepository;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserStepDefTests extends BaseStepDefs {


	@Autowired
	protected UserRepository userRepository;
	
	@And("^the DB is empty$")
	public void emptyDB() {
		userRepository.deleteAll();		
	}
	
	@When("^Client requests POST (.*) With JSON data$")
	public void performPostWithJsonDataToURL(String url, String jsonData) throws IOException {
		executePost(url, jsonData);
	}
	
	@Given("^Web-context is setup$")
	public void setupWebContext() {
		
	}
		
	@Then("^response code should be (\\d+)")
	public void chkResponseCode(int expRespCode) throws IOException {
		HttpStatus actual = latestResponse.getTheResponse().getStatusCode();
		assertThat("Status Code is Incorrect: " + latestResponse.getBody(), actual.value(), is(expRespCode));
	}
	
	@And("^result JSON should be$")
	public void chkResponseJson(String expJson) throws JSONException {
		JSONAssert.assertEquals(expJson, latestResponse.getBody(), false);
	}
	
	
	

}
