package com.ford.inventory.service;

import java.util.List;

import com.ford.inventory.domain.Vehicle;

public interface VehicleService {
	
	Vehicle get(String vin);
	
	String create(Vehicle vehicle);
	
	List<Vehicle> getVehiclesByType(String type);

}
