package com.ford.inventory.service;

import com.ford.inventory.domain.User;

public interface UserService {

	String create(User user);
	
	User get(Long id);
}
