package com.ford.inventory.domain;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User")
public class User{

	@Id
	private Long id;
	private String email;
	private String lName;
	private String fName;
	private String phone;
	private String userTyp;
	private String address;
	
	
	public User(Long id, String email, String lName, String fName, String phone, String userTyp, String address) {
		super();
		this.id = id;
		this.email = email;
		this.lName = lName;
		this.fName = fName;
		this.phone = phone;
		this.userTyp = userTyp;
		this.address = address;
		
	}
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUserTyp() {
		return userTyp;
	}
	public void setUserTyp(String userTyp) {
		this.userTyp = userTyp;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
