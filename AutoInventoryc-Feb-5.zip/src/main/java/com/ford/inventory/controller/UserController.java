package com.ford.inventory.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.inventory.domain.User;
import com.ford.inventory.dto.ResponseMsg;
import com.ford.inventory.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	UserService  userService;
	
	 
	private static final Logger LOG = LoggerFactory.getLogger(UserController.class);
 
	
	@PostMapping(value="/")
	public ResponseEntity<?> create(@RequestBody @Valid User user){
		String email = userService.create(user);
		LOG.debug("User created with email ID "+email);
		return new ResponseEntity<ResponseMsg>(new ResponseMsg("USER_ADDED", "User successfully added"), HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> get(@PathVariable Long id) {
		User user = userService.get(id);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
}
