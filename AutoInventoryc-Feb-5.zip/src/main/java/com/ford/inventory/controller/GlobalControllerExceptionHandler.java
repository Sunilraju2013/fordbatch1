package com.ford.inventory.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

import com.ford.inventory.dto.ResponseMsg;
import com.ford.inventory.service.ServiceException;


@ControllerAdvice
public class GlobalControllerExceptionHandler {
	@ResponseBody
	@ExceptionHandler(ServiceException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseMsg serviceExceptionHandler(ServiceException ex) {
		return new ResponseMsg(ex.getErrorCode(), ex.getMessage());
	}
}
