package com.ford.inventory;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.inventory.domain.Vehicle;
import com.ford.inventory.repository.VehicleReporsitory;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;

public class SearchStepDef extends SpringIntegrationTest{

	@Autowired
	private VehicleReporsitory vehicleReporsitory;

	private static final Logger LOGGER= LoggerFactory.getLogger(SearchStepDef.class);

	@And("^following vehicles exist$")
	public void and(DataTable items) throws Throwable {
		List<Vehicle> itemList = items.asList(Vehicle.class);
		LOGGER.debug("** list of vehicles from SearchStepDef : " + itemList);
		vehicleReporsitory.save(itemList);
	}
}
