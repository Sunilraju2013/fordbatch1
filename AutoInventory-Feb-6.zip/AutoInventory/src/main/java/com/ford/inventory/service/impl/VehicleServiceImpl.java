package com.ford.inventory.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ford.inventory.domain.Vehicle;
import com.ford.inventory.repository.VehicleReporsitory;
import com.ford.inventory.service.ServiceException;
import com.ford.inventory.service.VehicleService;

@Service
public class VehicleServiceImpl implements VehicleService {
	private static final Logger LOGGER= LoggerFactory.getLogger(VehicleServiceImpl.class);
	
	@Autowired
	private VehicleReporsitory vehicleRepository; 

	@Override
	//by default PK
	public Vehicle get(String vin) {		
		Vehicle vehicle = vehicleRepository.findOne(vin);
		if(null==vehicle)
			throw new ServiceException("Vehicle not found","VEHICLE_NOT_FOUND"); //msg, code
		return vehicle;
	}

	@Override
	public String create(Vehicle vehicle) {
		Vehicle addedVehicle = vehicleRepository.save(vehicle);
		return addedVehicle.getVin();
	}

	@Override
	public List<Vehicle> getVehiclesByType(String type) {
		List<Vehicle> resultList = vehicleRepository.findByType(type);
		LOGGER.debug("$$$$ getVehiclesByType: List size: " + resultList.size());
		return resultList;
	}

}
