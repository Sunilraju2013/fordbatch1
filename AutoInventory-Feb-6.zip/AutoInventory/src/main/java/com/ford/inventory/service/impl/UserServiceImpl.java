package com.ford.inventory.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ford.inventory.domain.User;
import com.ford.inventory.repository.UserRepository;
import com.ford.inventory.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired 
	UserRepository userRepository;
	
	@Override
	public String create(User user) {
		User saved = userRepository.save(user);
		return saved.getEmail();
	}

	@Override
	public User get(Long id) {
		return null;
	}

}
