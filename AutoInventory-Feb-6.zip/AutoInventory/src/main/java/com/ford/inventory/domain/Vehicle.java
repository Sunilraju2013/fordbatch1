package com.ford.inventory.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehicle")
public class Vehicle {

	@Id
	private String vin;
	private Integer year;
	private String model;
	private String transmission;
	private String trim;
	private String color;
	private String type;
	private Double price;
	private String dealerCode;
	
	public Vehicle(String vin, Integer year, String model, String transmission, String trim, String color, String type,
			Double price, String dealerCode) {
		super();
		this.vin = vin;
		this.year = year;
		this.model = model;
		this.transmission = transmission;
		this.trim = trim;
		this.color = color;
		this.type = type;
		this.price = price;
		this.dealerCode = dealerCode;
	}
	
	public Vehicle() {
		
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getTrim() {
		return trim;
	}
	public void setTrim(String trim) {
		this.trim = trim;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}	
	
	
	
}
