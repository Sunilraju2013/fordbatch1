package com.ford.inventory.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ford.inventory.domain.Vehicle;

public interface VehicleReporsitory extends CrudRepository<Vehicle, String> {
	
	List<Vehicle> findByType(String type);

}
